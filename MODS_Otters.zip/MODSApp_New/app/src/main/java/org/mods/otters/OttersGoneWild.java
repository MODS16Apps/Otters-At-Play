/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
 ***/
package org.mods.otters;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class OttersGoneWild extends Activity implements View.OnClickListener {
    private static final String TAG = "Sudoku";

    /**
     * Called when the activity is first created.
     */
    Button button;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.predators);

        Button next1 = (Button) findViewById(R.id.next1);
        next1.setOnClickListener(this);

        View homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(this);


    }

    // ...
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.next1:
                startActivity(new Intent(this, Relationships.class));
                break;
            case R.id.home:
                startActivity(new Intent (this, Sudoku.class));
                break;
        }
    }
}


