package org.mods.otters;

/**
 * Created by jared on 7/17/2016.
 */
public final class Config {

    private Config() {
    }

    public static final String YOUTUBE_API_KEY = "AIzaSyAlOtD29e5pjHaF6qEgpdLMlDeEmkcdalc";

}
