package org.mods.otters;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by jared on 7/27/2016.
 */
public class Credits extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.credits);
    }
}